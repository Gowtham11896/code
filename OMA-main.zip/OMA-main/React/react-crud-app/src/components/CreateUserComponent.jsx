import React, { Component } from 'react'
import OrderService from '../services/OrderService';

class CreateUserComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            
            id: this.props.match.params.id,
            orderName: '',
            productName: '',
            quantity: 0,
            totalPrice:0,
            shippingAddress:'',
            confirmedOrNot:'',
            orderStatus:'',
            errorMessage: ''
        }
        this.changeOrderNameHandler = this.changeOrderNameHandler.bind(this);
        this.changeProductNameHandler = this.changeProductNameHandler.bind(this);
        this.changeQuantityHandler = this.changeQuantityHandler.bind(this);
        this.changeTotalPriceHandler = this.changeTotalPriceHandler.bind(this);
        this.changeShippingAddressHandler = this.changeShippingAddressHandler.bind(this);
        this.changeconfirmedOrNotHandler = this.changeconfirmedOrNotHandler.bind(this);
        this.changeStatusHandler = this.changeStatusHandler.bind(this);

        this.saveOrUpdateUser = this.saveOrUpdateUser.bind(this);
    }

    componentDidMount() {
       
        if (this.state.id === '_add') {
            return
        } else {
            OrderService.getOrderById(this.state.id).then((res) => {
                let user = res.data;
                this.setState({
                    orderName: user.orderName, 
                    productName: user.productName, 
                    quantity: user.quantity,
                    totalPrice: user.totalPrice,
                    shippingAddress: user.shippingAddress,
                    confirmedOrNot: user.confirmedOrNot,
                    orderStatus: user.orderStatus
                });
            });
        }
    }
    
    saveOrUpdateUser = (e) => {
        e.preventDefault();
    
        let user = { 
            orderName: this.state.orderName, 
            productName: this.state.productName, 
            quantity: this.state.quantity,
            totalPrice: this.state.totalPrice,
            shippingAddress: this.state.shippingAddress,
            confirmedOrNot: this.state.confirmedOrNot,
            orderStatus: this.state.orderStatus
        };
    
        console.log('user => ' + JSON.stringify(user));
    
        if (this.state.id === '_add') {
            user.id = 0;
            OrderService.createOrder(user)
                .then(res => {
                    this.props.history.push('/orders');
                    alert('Order created successfully'); // Display success alert
                })
                .catch(err => {
                    this.setState({ errorMessage: err.message });
                    alert('Error creating order: ' + err.message); // Display error alert
                });
        } else {
            OrderService.updateOrder(user, this.state.id)
                .then(res => {
                    this.props.history.push('/orders');
                    alert('Order updated successfully'); // Display success alert
                })
                .catch(err => {
                    this.setState({ errorMessage: err.message });
                    alert('Error updating order: ' + err.message); // Display error alert
                });
        }
    }
    
    changeOrderNameHandler = (event) => {
        this.setState({ orderName: event.target.value });
    }

    changeProductNameHandler = (event) => {
        this.setState({ productName: event.target.value });
    }

    changeQuantityHandler = (event) => {
        this.setState({ quantity: event.target.value });
    }
    changeTotalPriceHandler = (event) => {
        this.setState({ totalPrice: event.target.value });
    }
    changeShippingAddressHandler = (event) => {
        this.setState({ shippingAddress: event.target.value });
    }
    changeconfirmedOrNotHandler = (event) => {
        this.setState({ confirmedOrNot: event.target.value });
    }
    changeStatusHandler = (event) => {
        this.setState({ orderStatus: event.target.value });
    }

    cancel() {
        this.props.history.push('/orders');
    }

    getTitle() {
        if (this.state.id === '_add') {
            return <h3 className="text-center">Add Order</h3>
        } else {
            return <h3 className="text-center">Update Order</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            {
                                this.getTitle()
                            }
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                        <label> Order Name: </label>
                                        <input placeholder="Order Name" name="orderName" className="form-control"
                                            value={this.state.orderName} onChange={this.changeOrderNameHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Product Name: </label>
                                        <input placeholder="Product Name" name="productName" className="form-control"
                                            value={this.state.productName} onChange={this.changeProductNameHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Quantity: </label>
                                        <input placeholder="Quantity" name="quantity" className="form-control"
                                            value={this.state.quantity} onChange={this.changeQuantityHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Total price: </label>
                                        <input placeholder="Total price" name="totalPrice" className="form-control"
                                            value={this.state.totalPrice} onChange={this.changeTotalPriceHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Shipping Address: </label>
                                        <input placeholder="Shipping Address" name="shippingAddress" className="form-control"
                                            value={this.state.shippingAddress} onChange={this.changeShippingAddressHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Confirmed Or Not: </label>
                                        <input placeholder="Confirmed Or Not" name="confirmedOrNot" className="form-control"
                                            value={this.state.confirmedOrNot} onChange={this.changeconfirmedOrNotHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label> Order Status: </label>
                                        <input placeholder="Order Status" name="orderStatus" className="form-control"
                                            value={this.state.orderStatus} onChange={this.changeStatusHandler} />
                                    </div>

                                    <button className="btn btn-success" onClick={this.saveOrUpdateUser}>Save</button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{ marginLeft: "10px" }}>Cancel</button>
                                    
                                    { this.state.errorMessage &&
                                    <h5 className="alert alert-danger"> 
                                    { this.state.errorMessage } </h5> }
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default CreateUserComponent
