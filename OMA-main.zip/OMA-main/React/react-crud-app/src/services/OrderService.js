import axios from 'axios';

const USER_API_BASE_URL = "http://localhost:47205/api/Orders";

class OrderService {

    getOrders(){
        return axios.get(USER_API_BASE_URL+'/GetOrders');
    }

    createOrder(order){
        console.log(order)
        return axios.post(USER_API_BASE_URL+'/addOrders', order);
    }

    getOrderById(OrderId){
        return axios.get(USER_API_BASE_URL +'/GetOrders' +'/' + OrderId);
    }

    updateOrder(order, OrderId){
        return axios.put(USER_API_BASE_URL + '/UpdateOrder'+'/' + OrderId, order);
    }

    deleteOrder(OrderId){
        return axios.delete(USER_API_BASE_URL +'/Delete' +'/' + OrderId);
    }
}

export default new OrderService()