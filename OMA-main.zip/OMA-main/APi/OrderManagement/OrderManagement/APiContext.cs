﻿using Microsoft.EntityFrameworkCore;
using OrderManagement.Models;

namespace OrderManagement
{
    public class APiContext:DbContext
    {
        public APiContext(DbContextOptions<APiContext> options) : base(options)
        {
                
        }

        public DbSet<orders> orders { get; set; }

    }
}
