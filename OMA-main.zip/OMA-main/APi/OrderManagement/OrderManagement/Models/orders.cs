﻿using System.ComponentModel.DataAnnotations;

namespace OrderManagement.Models
{
    public class orders
    {
        public int Id { get; set; }
        public string OrderName { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }
        public string ShippingAddress { get; set; }
        public string ConfirmedOrNot { get; set; }
        public string OrderStatus { get; set; }



    }
}
