﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderManagement.Models;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly APiContext db;
        
        public OrdersController(APiContext db) {
            this.db=db;
        }
        [HttpPost]
        [Route("addOrders")]
        public async Task<IActionResult> AddOrders([FromBody] orders e)
        {
                db.orders.Add(e);
                int res = await db.SaveChangesAsync();
                if (res > 0)
                {
                    return Ok("Order Added");
                }
                return NotFound();

        }
        [HttpGet]
        [Route("GetOrders")]
        public async Task<IActionResult> GetOrders()
        {

            var res =await db.orders.ToListAsync();
            return Ok(res);

        }
        [HttpGet]
        [Route("GetOrders/{id}")]
        public async Task<IActionResult> GetOrders(int id)
        {
            var res = await db.orders.Where(x => x.Id == id).FirstOrDefaultAsync();
            if(res!=null)
            {
                return Ok(res);
            }
            return NotFound();
        }

        [HttpPut]
        [Route("UpdateOrder/{id}")]
        public async Task<IActionResult> UpdateOrders(int id, orders e)
        {
            var ar = await db.orders.Where(x => x.Id == id).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.OrderName = e.OrderName;
                ar.ProductName = e.ProductName;
                ar.Quantity = e.Quantity;
                ar.TotalPrice = e.TotalPrice;
                ar.ShippingAddress = e.ShippingAddress;
                ar.ConfirmedOrNot = e.ConfirmedOrNot;
                ar.OrderStatus = e.OrderStatus;

                int res = await db.SaveChangesAsync();
                if (res > 0)
                {
                    return Ok("Order Details updated");
                }
                return BadRequest("not updated");
            }
            return BadRequest("not updated");

        }

        [HttpDelete]
        [Route("Delete/{id}")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var res = await db.orders.Where(x => x.Id == id).FirstOrDefaultAsync();

            if (res!=null)
            {
                db.orders.Remove(res);
                int res1=await db.SaveChangesAsync();
                if(res1>0)
                {
                    return Ok("Order Deleted");
                }
            }
            return NotFound();
        }
    }
}
